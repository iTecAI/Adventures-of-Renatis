Supported platforms: windows 7, 10. MacOS will cause OSErrors an pygame.errors due to path incompatibility.

Run main.py to play.

If an ImportError occurs, make sure pygame is installed. If it is, your builtins may be missing some libraries. If not, drag the folders "include" and "Lib" inside your main python directory, and click "Merge" if prompted.