'''instructions:
Arrow keys to move
Click on signs to read
Click on monsters (green blobs and skeletons) to attack
Press T when really near another person to talk
Go into dark doors to go between locations (dungeons, castles, etc)
Find the gold star to win
And that's it! Have fun!!!
'''
from os import listdir, system
try:
    import pygame
except ImportError:
    system('/Library/Frameworks/Python.framework/Versions/3.6/bin/pip3 install pygame')
from json import loads
import random
pygame.init()

import os.path
import time
import math

#pf import
from pathfinding.core.diagonal_movement import DiagonalMovement
from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder

from threading import Thread, active_count

from copy import deepcopy

#setup
screen = pygame.display.set_mode((640,640))

class Map:
    def load(self, pyimg, mapdata):
        with open('assets\\textures\\tiles.json','r') as j:
            database = loads(j.read())
        for t in database.keys():
            print(database[t]['type'])
            if not database[t]['type'] in ['procedural','adj-conditional']:
                try:
                    database[t]['path'] = pygame.image.load('assets\\textures\\'+database[t]['path'])
                except OSError:
                    print('Incorrect image reference. Setting to PH.')
                    database[t]['path'] = pygame.image.load('assets\\textures\\placeholder.png')
                except KeyError:
                    try:
                        paths = database[t]['paths']
                        c = 0
                        for p in paths:
                            try:
                                database[t]['paths'][c][0] = pygame.image.load('assets\\textures\\'+p[0])
                            except OSError:
                                print('Incorrect image reference. Setting to PH.')
                                database[t]['paths'][c][0] = pygame.image.load('assets\\textures\\placeholder.png')
                            c += 1
                    except KeyError:
                        print('No image reference found. Setting to PH.')
                        database[t]['paths'] = [pygame.image.load('assets\\textures\\placeholder.png'),1]
            if database[t]['type'] == 'roof':
                database[t]['floor'] = pygame.image.load('assets\\textures\\'+database[t]['floor'])
        
                    
        map_surf = pygame.Surface([pyimg.get_width() * 32, pyimg.get_height() * 32],flags=pygame.SRCALPHA)
        roof_surf = pygame.Surface([pyimg.get_width() * 32, pyimg.get_height() * 32],flags=pygame.SRCALPHA)
        map_array = []
        roof_array = []
        collide_list = []
        spawners = []
        pathfind_array = []
        for x in range(pyimg.get_width()):
            map_array.append([])
            roof_array.append([])
            pathfind_array.append([])
            for y in range(pyimg.get_height()):
                for t in database.keys():
                    if list(pyimg.get_at([x,y])[:3]) == database[t]['color']:
                        map_array[x].append(database[t]['id'])
                        pathfind_array[x].append(1)
                        if database[t]['type'] == 'roof':
                            roof_array[x].append(1)
                        else:
                            roof_array[x].append(0)
        for i in map_array:
            if i == []:
                map_array.remove([])
        dirs = [[(0,-1),(1,0),(0,1),(-1,0)],[(0,-1),(1,-1),(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1)]]
        tb = None
        for x in range(pyimg.get_width()):
            map_array.append([])
            for y in range(pyimg.get_height()):
                for t in database.keys():
                    if str(x) + ',' + str(y) in mapdata['tiles']:
                        for tile in mapdata['tiles'][str(x) + ',' + str(y)]:
                            if tile['type'] == 'collider':
                                collide_list.append(pygame.Rect(x*32,y*32,32,32))
                            if tile['type'] == 'spawner':
                                spawners.append({'id':str(x) + ',' + str(y),'stats':tile['stats'],'pos':[x,y],'chance':tile['spawnchance'],'tick':tile['spawntick'],'cgen':tile['cgen']})
                    if list(pyimg.get_at([x,y])[:3]) == database[t]['color']:
                        if database[t]['type'] == 'static':
                            tb = database[t]['path']
                        elif database[t]['type'] == 'vary':
                            select_list = []
                            for p in database[t]['paths']:
                                for c in range(p[1]):
                                    select_list.append(p[0])
                            tb = random.choice(select_list)
                        elif database[t]['type'] == 'roof':
                            if str(x) + ',' + str(y) in mapdata['tiles']:
                                for tile in mapdata['tiles'][str(x) + ',' + str(y)]:
                                    if tile['type'] == 'floor':
                                        tb = pygame.image.load('assets\\textures\\'+tile['floor'])
                                        break
                                if not tb:
                                    tb = database[t]['floor']
                            else:
                                tb = database[t]['floor']
                            roof_surf.blit(database[t]['path'],(x*32,y*32))
                        elif database[t]['type'] == 'adj-conditional':
                            cur_c = None
                            for c in database[t]['conditions'].keys():
                                DIR = c.split('=')[0]
                                ID = c.split('=')[1]
                                cur_c = c
                                if DIR == 'n' and map_array[x][y-1] == ID:
                                    break
                                if DIR == 'e' and map_array[x-1][y] == ID:
                                    break
                                if DIR == 's' and map_array[x][y+1] == ID:
                                    break
                                if DIR == 'w' and map_array[x+1][y] == ID:
                                    break
                            tb = pygame.image.load('assets\\textures\\' + database[t]['conditions'][cur_c])
                        
                        elif database[t]['type'] == 'procedural':
                            if 'path' in database[t]['flags']:
                                check = False
                                for v in database[t]['variants'].keys():
                                    for ap in database[t]['variants'][v]['apos']:
                                        check = False
                                        #print('CHK'+v)
                                        if len(ap[1]) == 4:
                                            #print('NESW')
                                            check = True
                                            for d in range(4):
                                                if map_array[x+dirs[0][d][1]][y+dirs[0][d][0]] == database[t]['id'] and ap[1][d] == '1':
                                                    #print('CYES'+str(x+dirs[0][d][1])+' '+str(y+dirs[0][d][0]) + '<-' + str((y,x)))
                                                    check = check and True
                                                elif map_array[x+dirs[0][d][1]][y+dirs[0][d][0]] != database[t]['id'] and ap[1][d] == '0':
                                                    #print('CNO'+str(x+dirs[0][d][1])+' '+str(y+dirs[0][d][0]) + '<-' + str((y,x)))
                                                    check = check and True
                                                else:
                                                    #print('NC'+str(x+dirs[0][d][1])+' '+str(y+dirs[0][d][0]) + '<-' + str((y,x)))
                                                    check = check and False
                                        elif len(ap[1]) == 8:
                                            #print('NDEDSDWD')
                                            check = True
                                            for d in range(8):
                                                if map_array[x+dirs[1][d][1]][y+dirs[1][d][0]] == database[t]['id'] and ap[1][d] == '1':
                                                    #print('CYES'+str(x+dirs[1][d][1])+' '+str(y+dirs[1][d][0]) + '<-' + str((y,x)))
                                                    check = check and True
                                                elif map_array[x+dirs[1][d][1]][y+dirs[1][d][0]] != database[t]['id'] and ap[1][d] == '0':
                                                    #print('CNO'+str(x+dirs[1][d][1])+' '+str(y+dirs[1][d][0]) + '<-' + str((y,x)))
                                                    check = check and True
                                                else:
                                                    #print('NC'+str(x+dirs[1][d][1])+' '+str(y+dirs[1][d][0]) + '<-' + str((y,x)))
                                                    check = check and False
                                        else:
                                            #print(ap[1])
                                            pass
                                        if check:
                                            #print('DO' + v)
                                            tb = pygame.transform.rotate(pygame.image.load('assets\\textures\\' + database[t]['top'] + '.' + v + '.png').convert_alpha(),ap[0])
                                            break
                                        #print('SECT')
                                    if check:
                                        break
                                if not check:
                                    tb = pygame.image.load('assets\\textures\\' + database[t]['top'] + '.' + database[t]['fallback'] + '.png').convert_alpha()
                                
                        else:
                            print(database[t]['type'])

                        if database[t]['type'] != 'roof':
                            roof_surf.fill((0,0,0,0),rect=pygame.Rect((x*32,y*32),(32,32)))
                        if 'rotate' in database[t]['flags']:
                            tb = pygame.transform.rotate(tb, random.randint(0,3)*90).convert_alpha()
                        if 'collider' in database[t]['flags']:
                            collide_list.append(pygame.Rect(x*32,y*32,32,32))
                            pathfind_array[x][y] = 0
                        map_surf.blit(tb, (x*32,y*32))
        return collide_list, map_surf, map_array, roof_array, roof_surf, pathfind_array, spawners
    
    def __init__(self, mapfolder, dimname='overworld'):
        with open(mapfolder + '\\' + dimname + '.json','r') as j:
            self.collidelist, self.map, self.array, self.roofa, self.roofs, self.pathfind_array, self.spawners = self.load(pygame.image.load(mapfolder + '\\' + dimname + '.png').convert_alpha(),loads(j.read()))
    def get_at(self, pos, mapdata, ppos, wide=False):
        if wide:
            for i in [(1,1),(1,0),(1,-1),(0,1),(0,0),(0,-1),(-1,1),(-1,0),(-1,-1)]:
                if pos == ppos:
                    array_pos = (round(pos[0]/32)+i[0],round(pos[1]/32)+i[1])
                else:
                    array_pos = (round(ppos[0]/32)+round((pos[0]-320)/32)+i[0],round(ppos[1]/32)+round((pos[1]-320)/32)+i[1])
                try:
                    if str(array_pos[0]) + ',' + str(array_pos[1]) in mapdata["tiles"].keys():
                        return mapdata["tiles"][str(array_pos[0]) + ',' + str(array_pos[1])]
                    else:
                        pass
                except OSError:
                    return None
            if pos == ppos:
                array_pos = (round(pos[0]/32),round(pos[1]/32))
            else:
                array_pos = (round(ppos[0]/32)+round((pos[0]-320)/32),round(ppos[1]/32)+round((pos[1]-320)/32))
            return self.array[array_pos[0]][array_pos[1]]
        else:
            if pos == ppos:
                array_pos = (round(pos[0]/32),round(pos[1]/32)+1)
            else:
                array_pos = (round(ppos[0]/32)+round((pos[0]-320)/32),round(ppos[1]/32)+round((pos[1]-320)/32))
            try:
                if str(array_pos[0]) + ',' + str(array_pos[1]) in mapdata["tiles"].keys():
                    return mapdata["tiles"][str(array_pos[0]) + ',' + str(array_pos[1])]
                else:
                    return self.array[array_pos[0]][array_pos[1]]
            except OSError:
                return None

class Character:
    def __init__(self,sheet='assets\\character\\gen_people\\download.png',MAP='map2',dim='overworld'):
        #load animations from sheet
        self.msgrender = -1
        self.msgdata = {}
        self.vignette = None
        rowdefs = [('spell_n',7),('spell_w',7),('spell_s',7),('spell_e',7),
                   ('thrust_n',8),('thrust_w',8),('thrust_s',8),('thrust_e',8),
                   ('walk_n',9),('walk_w',9),('walk_s',9),('walk_e',9),
                   ('slash_n',6),('slash_w',6),('slash_s',6),('slash_e',6),
                   ('shoot_n',13),('shoot_w',13),('shoot_s',13),('shoot_e',13),
                   ('hurt',6)]
        self.sheet = sheet
        sheet = pygame.image.load(sheet)
        transurface = pygame.Surface((825,1330),flags=pygame.SRCALPHA)
        transurface.blit(sheet,(0,0),area=pygame.Rect((7,14),(825,1330)))
        self.sprites = {}
        rc = 0
        for r in rowdefs:
            self.sprites[r[0]] = []
            for c in range(r[1]):
                ts = pygame.Surface((64,64),flags=pygame.SRCALPHA)
                ts.blit(transurface,(0,0),area=pygame.Rect(c*64,rc*64,64,54))
                self.sprites[r[0]].append(ts)
            rc += 1
        #setup sprite attrs
        self.attrs = {}
        self.maps = {}
        self.mapdata = {}
        self.mapfolder = MAP
        dims = listdir('assets\\maps\\' + MAP)
        for i in dims:
            if i.endswith('.png'):
                self.maps[i[:len(i)-4]] = Map(str('assets\\maps\\' + MAP + '\\'),dimname=i[:len(i)-4])
            else:
                tf = open('assets\\maps\\' + MAP + '\\'+ i,'r')
                self.mapdata[i[:len(i)-5]] = loads(tf.read())
                tf.close()
        self.cur_map_name = dim
        self.cur_map = self.maps[self.cur_map_name]
        self.cur_sprite = self.sprites['walk_s'][0]
        self.dir = 's'
        self.animation_stage = 0
        self.pos = [self.mapdata[self.cur_map_name]['start'][0]*32,self.mapdata[self.cur_map_name]['start'][1]*32]
        print(self.pos)
        self.move_stage = 0
        print(len(self.cur_map.array))
        print(len(self.cur_map.array[0]))
        self.def_extra_render = {'sign':None,'npc':None}
        self.extra_render = dict(self.def_extra_render)
        self.last_att = time.time()-1
        self.entthreads = {}
        self.spawners_used = {}
        self.entities = {}
        for i in self.mapdata[self.cur_map_name]['npcs'].keys():
            npc = self.mapdata[self.cur_map_name]['npcs'][i]
            print(npc)
            self.entities[i] = Villager([npc['start'][0]*32,npc['start'][1]*32],npc['sheet'],self,use_cgen=True,message=npc['msg'],name=i)

        #stats
        self.hp = 100
        self.win = False

        #define constant textures
        self.font = pygame.font.Font('assets\\font\\retganon.ttf',16)
        self.backdrop = pygame.transform.scale(pygame.image.load('assets\\misc\\outeredge.png'),(len(self.cur_map.array)*32+1000,int(len(self.cur_map.array[0])*64)+1000))
        self.selector = pygame.image.load('assets\\misc\\blockselector.png')
        self.vignettes = {}
        for i in os.listdir('assets\\character\\vignette'):
            if i.endswith('.png'):
                self.vignettes[i] = pygame.image.load('assets\\character\\vignette\\'+i)
        self.roof = True
        self.bars = {}
        
        for i in os.listdir('assets\\textures\\gui\\bars\\'):
            namelist = i.split('.')
            if namelist[0] in self.bars.keys():
                self.bars[namelist[0]][namelist[1]] = pygame.image.load('assets\\textures\\gui\\bars\\'+i)
            else:
                self.bars[namelist[0]] = {}
                self.bars[namelist[0]][namelist[1]] = pygame.image.load('assets\\textures\\gui\\bars\\'+i)
        
    def move(self,spd=1,direction='s'):
        self.dir = direction
        self.cur_sprite = self.sprites['walk_'+self.dir][self.animation_stage]
        if direction == 'e':
            self.pos[0] += spd
            if pygame.Rect(self.pos[0]+10,self.pos[1],22,48).collidelist(self.cur_map.collidelist) != -1 or self.pos[0] >= (len(self.cur_map.array)*16)-32:
                self.pos[0] -= spd
        if direction == 's':
            self.pos[1] += spd
            if pygame.Rect(self.pos[0]+10,self.pos[1],22,48).collidelist(self.cur_map.collidelist) != -1 or self.pos[1] >= (len(self.cur_map.array[0])*32)-64:
                self.pos[1] -= spd
        if direction == 'w':
            self.pos[0] -= spd
            if pygame.Rect(self.pos[0]+10,self.pos[1],22,48).collidelist(self.cur_map.collidelist) != -1 or self.pos[0] <= 0:
                self.pos[0] += spd
        if direction == 'n':
            self.pos[1] -= spd
            if pygame.Rect(self.pos[0]+10,self.pos[1],22,48).collidelist(self.cur_map.collidelist) != -1 or self.pos[1] <= 0:
                self.pos[1] += spd
        if self.move_stage % 3 == 0:
            self.animation_stage += 1
            if self.animation_stage >= len(self.sprites['walk_'+self.dir]):
                self.animation_stage = 0
        self.move_stage += 1
    def render(self):
        blitsurf = pygame.Surface((640,640))
        blitsurf.blit(self.backdrop, (self.pos[0]/-1-500,self.pos[1]/-1-500))
        blitmap = self.cur_map.map.copy()
        entities = dict(self.entities)
        try:
            for i in entities.keys():
                if entities[i].render:
                    entities[i].render_task()
                    blitmap.blit(entities[i].img, entities[i].pos)
                else:
                    del entities[i]
        except RuntimeError:
            pass
        self.entities = dict(entities)
        blitsurf.blit(blitmap, (320-self.pos[0],320-self.pos[1]))
        blitsurf.blit(self.selector,(round(pygame.mouse.get_pos()[0]/32)*32-self.pos[0]%32+1,round(pygame.mouse.get_pos()[1]/32)*32-self.pos[1]%32+1))
        cooldown = time.time() - self.last_att
        if cooldown > 1:
            cooldown = 1
        if cooldown < 1:
            self.cur_sprite = self.sprites['slash_'+self.dir][round((round(cooldown,1)*10)%6)]
        else:
            self.cur_sprite = self.sprites['walk_'+self.dir][self.animation_stage]
        blitsurf.blit(self.cur_sprite, (320,320))
        
        if self.roof:
            blitsurf.blit(self.cur_map.roofs, (320-self.pos[0],320-self.pos[1]))
        #blit vignette
        if self.vignette:
            blitsurf.blit(self.vignette, (0,0))
        for i in self.extra_render.values():
            if i != None:
                blitsurf.blit(i[0],i[1])
        #self.extra_render = dict(self.def_extra_render)

        #render bars
        blitsurf.blit(pygame.transform.scale(self.bars['health']['slice'],(self.hp*2,28)),(25,15))
        blitsurf.blit(self.bars['health']['symbol'],(10,10))
        blitsurf.blit(pygame.transform.scale(self.bars['energy']['slice'],(int(cooldown*200),28)),(20,61))
        blitsurf.blit(self.bars['energy']['symbol'],(10,56))
        
        return blitsurf
    def distance_to(self, pos, mode="tile"):
        moded = {"tile":32,"absolute":1}
        diffx = round(abs(self.pos[0]-pos[0])/moded[mode])
        diffy = round(abs(self.pos[1]-pos[1])/moded[mode])
        return (math.sqrt(diffx**2 + diffy**2),diffx,diffy)
    def spawn(self):
        for i in self.cur_map.spawners:
            if random.randint(1,100) < i['chance'] and round(time.time())%i['tick'] == 0 and len(self.entities) < self.mapdata[self.cur_map_name]['mobcap']:
                if not round(time.time()) in self.spawners_used.values():
                    self.spawners_used[i['id']] = round(time.time())
                    types = {'slime':'assets\\living\\slime','skeleton':'assets\\living\\skeleton\\sheet.png'}
                    att = eval(i['stats']['att'],globals(),locals())
                    hp = eval(i['stats']['hp'],globals(),locals())
                    spd = eval(i['stats']['spd'],globals(),locals())
                    try:
                        typ = types[eval(i['stats']['type'],globals(),locals())]
                    except KeyError:
                        typ = random.choice(list(types.values()))
                    if i['cgen'] == 0:
                        self.entities[str(time.time())] = Monster([i['pos'][0]*32,i['pos'][1]*32],typ,self,animated=False,att=att,hp=hp,spd=spd)
                    else:
                        self.entities[str(time.time())] = Monster([i['pos'][0]*32,i['pos'][1]*32],typ,self,use_cgen=True,att=att,hp=hp,spd=spd)
    def switchdim(self,dim,pos):
        self.__init__(sheet=self.sheet, MAP=self.mapfolder, dim=dim)
        self.pos = pos
                    
    def check(self):
        bp = pygame.mouse.get_pressed()
        kp = pygame.key.get_pressed()
        intersecting = self.cur_map.get_at(self.pos,self.mapdata[self.cur_map_name],self.pos,wide=True)
        narrow_int = self.cur_map.get_at(self.pos,self.mapdata[self.cur_map_name],self.pos)
        
        my_ap = (round(self.pos[0]/32),round(self.pos[1]/32))
        if self.cur_map.roofa[my_ap[0]][my_ap[1]]:
            self.vignette = self.vignettes['house.png']
            self.roof = False
        else:
            self.roof = True
            self.vignette = None
        try:
            gtagx = self.mapdata[self.cur_map_name]['tiles'][str(round(self.pos[0]/32)) + ',' + str(round(self.pos[1]/32))]
            for gtag in gtagx:
                if gtag['type'] == 'gateway':
                    self.switchdim(gtag['dimension'], [gtag['pos'][0]*32,gtag['pos'][1]*32])
                    break
        except KeyError:
            pass
        if narrow_int == '08':
            self.win = True
        if bp[0]:
            tileclick = self.cur_map.get_at(pygame.mouse.get_pos(),self.mapdata[self.cur_map_name],self.pos,wide=True)
            if type(tileclick) == list:
                for i in tileclick:
                    if i['type'] == 'message' and self.extra_render['sign'] == None:
                        msgsurf = pygame.image.load('assets\\textures\\gui\\message.sign.png')
                        msgsurf.blit(self.font.render(i['msg'],True,[0,0,0]),(15,15))
                        self.extra_render['sign'] = (msgsurf,(20,520))
                        self.msgdata = i
        '''if self.extra_render['sign'] != None:
            msgsurf = pygame.image.load('assets\\textures\\gui\\message.sign.png')
            msgsurf.blit(self.font.render(self.msgdata['msg'],True,[0,0,0]),(15,15))
            self.extra_render['signs'] = (msgsurf,(20,520))'''

        #keychecks
        if kp[pygame.K_RETURN]:
            self.extra_render['sign'] = None
            print('sc')
        if kp[pygame.K_x]:
            self.extra_render['npc'] = None

        self.spawn()
class DynamicObject:
    def c_init(self, kwargs):
        pass
    def __init__(self, pos, imgfolder, player, animated=False, use_cgen=False, **kwargs):
        self.pos = pos
        print(kwargs)
        self.render = True
        self.animated = animated
        self.player = player
        self.cur_map = player.cur_map
        self.collidelist = self.cur_map.collidelist
        self.path = []
        if use_cgen:
            self.animated = True
            rowdefs = [('n',9),('w',9),('s',9),('e',9),]
            self.sheet = imgfolder
            sheet = pygame.image.load(self.sheet)
            transurface = pygame.Surface((825,1330),flags=pygame.SRCALPHA)
            transurface.blit(sheet,(0,0),area=pygame.Rect((7,14),(825,1330)))
            self.imgs = {}
            rc = 8
            for r in rowdefs:
                self.imgs[r[0]] = {}
                for c in range(r[1]):
                    ts = pygame.Surface((64,64),flags=pygame.SRCALPHA)
                    ts.blit(transurface,(0,0),area=pygame.Rect(c*64,rc*64,64,54))
                    self.imgs[r[0]][str(c)] = ts
                    self.img = ts
                rc += 1
            print(self.imgs)

        else:
            try:
                if self.animated:
                    self.imgs = {'n':{},'e':{},'s':{},'w':{}}
                    self.img = None
                    for i in os.listdir(imgfolder):
                        elements = i.split('.')
                        self.img = pygame.image.load(imgfolder + '\\' + i)
                        self.imgs[elements[0]][elements[1]] = self.img
                else:
                    self.img = pygame.image.load(imgfolder + '\\main.png')
            except IndexError:
                print('Sprite frame name error. Please keep sprite names in the form "direction (n,e,s,w).frame stage (0-infinity).png"')
            except KeyError:
                print('Sprite frame name error. Please keep sprite names in the form "direction (n,e,s,w).frame stage.png"')
            except OSError:
                if not self.animated:
                    print('Your sprite is not animated. Name your sprite\'s image "main.png"')
                else:
                    raise OSError
                    
        self.dir = random.choice('nesw')
        if self.animated:
            self.astage = 0
            self.ac = 0
        self.smooth = [0,0,0,'n']
        self.aiR = True
        self.c_init(kwargs)
        
    def move(self,spd=3,direction='n',smooth=1):
        if self.smooth[0] == 0:
            self.smooth = [round(spd/smooth)-1,smooth,spd,direction]
        self.dir = direction
        if self.animated:
            self.img = self.imgs[self.dir][str(self.astage)]
            if self.ac%3 == 0:
                self.astage += 1
                if self.astage == len(self.imgs[self.dir].keys()):
                    self.astage = 0
            self.ac += 1
        if direction == 'e':
            self.pos[0] += round(spd/smooth)
            if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[0] >= (len(self.cur_map.array)*16)-32:
                self.pos[0] -= round(spd/smooth)
                return False
            return True
        if direction == 's':
            self.pos[1] += round(spd/smooth)
            if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[1] >= (len(self.cur_map.array[0])*32)-64:
                self.pos[1] -= round(spd/smooth)
                return False
            return True
        if direction == 'w':
            self.pos[0] -= round(spd/smooth)
            if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[0] <= 0:
                self.pos[0] += round(spd/smooth)
                return False
            return True
        if direction == 'n':
            self.pos[1] -= round(spd/smooth)
            if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[1] <= 0:
                self.pos[1] += round(spd/smooth)
                return False
            return True
    def distance_to(self, pos, mode="tile"):
        moded = {"tile":32,"absolute":1}
        diffx = round(abs(self.pos[0]-pos[0])/moded[mode])
        diffy = round(abs(self.pos[1]-pos[1])/moded[mode])
        return (math.sqrt(diffx**2 + diffy**2),diffx,diffy)
    def pathfind(self, pos1, pos2,dither=False):
        path = self.path
        pgrid = Grid(matrix=self.cur_map.pathfind_array)
        if dither:
            try:
                s = pgrid.node(pos1[0]+random.randint(0,2),pos1[1]+random.randint(0,2))
                e = pgrid.node(pos2[0]+random.randint(0,2),pos2[1]+random.randint(0,2))
            except:
                s = pgrid.node(pos1[0],pos1[1])
                e = pgrid.node(pos2[0],pos2[1])
        else:
            s = pgrid.node(pos1[0],pos1[1])
            e = pgrid.node(pos2[0],pos2[1])
        if len(self.path) == 0:
            finder = AStarFinder(diagonal_movement=DiagonalMovement.never)
        else:
            finder = AStarFinder(diagonal_movement=DiagonalMovement.never,max_runs=20)
        try:
            path, runs = finder.find_path(s, e, pgrid)
        except:
            pass
        return path
    def render_task(self):
        if self.smooth[1]>1 and self.smooth[0]>0:
            spd = self.smooth[2]
            smooth = self.smooth[1]
            direction = self.smooth[3]
            if direction == 'e':
                self.pos[0] += round(spd/smooth)
                if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[0] >= (len(self.cur_map.array)*16)-32:
                    self.pos[0] -= round(spd/smooth)
            if direction == 's':
                self.pos[1] += round(spd/smooth)
                if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[1] >= (len(self.cur_map.array[0])*32)-64:
                    self.pos[1] -= round(spd/smooth)
            if direction == 'w':
                self.pos[0] -= round(spd/smooth)
                if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[0] <= 0:
                    self.pos[0] += round(spd/smooth)
            if direction == 'n':
                self.pos[1] -= round(spd/smooth)
                if pygame.Rect(self.pos[0]+10,self.pos[1],self.img.get_width(),self.img.get_height()).collidelist(self.cur_map.collidelist) != -1 or self.pos[1] <= 0:
                    self.pos[1] += round(spd/smooth)
            self.smooth[0] -= 1
    def ai(self):
        self.keys = pygame.key.get_pressed()
        self.looptask()
        pd = self.distance_to(self.player.pos,mode='absolute')
        if abs(pd[0]) < 480 or abs(pd[1]) < 480 and self.aiR:
            self._ai()
            #print(pd)
        else:
            pass
    def looptask(self):
        pass
    def _ai(self):
        pass
        

class Villager(DynamicObject):
    def c_init(self, kwargs):
        self.message = kwargs['message']
        self.name = kwargs['name']
        self.speed = random.randint(10,20)
        self.aiLT = time.time()
        #print(self.pathfind((round(self.pos[0]/32),round(self.pos[1]/32)), self.ai_target))
        self.path_stage = 0
        self.path = []
        self.rnm = 0
    def _ai(self):
        if random.randint(0,5) == 0:
            self.dir = random.choice('nesw')
        self.move(spd=self.speed,direction=self.dir,smooth=5)
    def looptask(self):
        if self.distance_to(self.player.pos,mode='absolute')[0] < 64 and self.aiR and self.player.extra_render['npc'] == None and self.keys[pygame.K_t]:
            self.aiR = False
            msgsurf = pygame.image.load('assets\\textures\\gui\\message.npc.png')
            msgsurf.blit(self.player.font.render(self.name + ': ' + self.message,True,[0,0,0]),(15,15))
            self.player.extra_render['npc'] = (msgsurf,(20,520))
        else:
            self.aiR = True

class Monster(DynamicObject):
    def c_init(self, kwargs):
        self.hp = kwargs['hp']
        self.att = kwargs['att']
        self.speed = kwargs['spd']
        #print(self.ai_target)
        self.aiLT = time.time()
        #print(self.pathfind((round(self.pos[0]/32),round(self.pos[1]/32)), self.ai_target))
        self.path_stage = 0
        self.path = []
        self.rnm = 0
        self.tloop = 0
        self.render = True
        self.scp = (320,320)
    def _ai(self):
        self.ai_target = (int(self.player.pos[0]/32),int(self.player.pos[1]/32))
        self.pp = [round(self.pos[0]/32),round(self.pos[1]/32)]
        if self.path_stage == len(self.path):
            self.path = self.pathfind((round(self.pos[0]/32),round(self.pos[1]/32)), self.ai_target, dither=True)
            c = 0
            for i in self.path:
                self.path[c] = [i[0]-0,i[1]-0]
                c += 1
            self.path_stage = 0
        else:
            try:
                if self.path[self.path_stage][0] > round(self.pos[0]/32):
                    moved = self.move(spd=self.speed,direction='e',smooth=5)
                elif self.path[self.path_stage][0] < round(self.pos[0]/32):
                    moved = self.move(spd=self.speed,direction='w',smooth=5)
                elif self.path[self.path_stage][1] > round(self.pos[1]/32):
                    moved = self.move(spd=self.speed,direction='s',smooth=5)
                elif self.path[self.path_stage][1] < round(self.pos[1]/32):
                    moved = self.move(spd=self.speed,direction='n',smooth=5)
                else:
                    moved = True
                if moved:#self.pp == [round(self.pos[0]/32),round(self.pos[1]/32)]:
                    self.path_stage += 1
                    self.rnm = 0
                else:
                    self.rnm += 1
                    self.path = self.pathfind((round(self.pos[0]/32),round(self.pos[1]/32)), self.ai_target, dither=True)
                    c = 0
                    for i in self.path:
                        self.path[c] = [i[0]-1,i[1]-1]
                        c += 1
                    self.path_stage = 0
                #print(str(self.pos[0]/32)+','+str(self.pos[1]/32))
            except TypeError:
                self.path = []
                self.path_stage = 0
                print('Etc')
                self.aiLT = time.time()
                self.rnm = 0
        if time.time() > self.aiLT + 45 or self.rnm > 20:
            self.path = []
            self.path_stage = 0
            #print('tc')
            self.aiLT = time.time()
            self.rnm = 0
    def looptask(self):
        self.scp = [self.pos[0] - self.player.pos[0] + 320,self.pos[1] - self.player.pos[1] + 320]
        if pygame.Rect(self.player.pos,(22,48)).colliderect(pygame.Rect(self.pos, self.img.get_rect().size)) and round(time.time())%2 == 0 and round(time.time()) != self.tloop:
            self.player.hp -= self.att
            self.tloop = round(time.time())
        if pygame.Rect(self.scp, self.img.get_rect().size).collidepoint(pygame.mouse.get_pos()) and pygame.mouse.get_pressed()[0] and time.time() > self.player.last_att+1 and self.distance_to(self.player.pos,mode='absolute')[0]<=128:
            self.hp -= 5
            self.player.last_att = time.time()
        if self.hp < 1:
            self.render = False

def main():
    pygame.mouse.set_cursor(*pygame.cursors.broken_x)
    global screen
    c = Character()
    DynamicObject([0,0],'assets\\character\\gen_people\\download.png',c,animated=True,use_cgen=True)
                  
    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                exit(0)
        kp = pygame.key.get_pressed()
        if kp[pygame.K_UP]:
            c.move(spd=6,direction='n')
        if kp[pygame.K_RIGHT]:
            c.move(spd=6,direction='e')
        if kp[pygame.K_DOWN]:
            c.move(spd=6,direction='s')
        if kp[pygame.K_LEFT]:
            c.move(spd=6,direction='w')
        for i in c.entities.keys():
            if c.entities[i].render:
                c.entthreads[i] = Thread(target=c.entities[i].ai)
                c.entthreads[i].start()
        c.check()
        try:
            screen.blit(c.render(), (0,0))
        except ValueError:
            pass
        pygame.display.flip()
        pygame.time.Clock().tick(100)
        if c.hp < 1 or c.win:
            run = False
    if c.win:
        screen.blit(pygame.image.load('assets\\textures\\gui\\winner.png'), (0,0))
    else:
        screen.blit(pygame.image.load('assets\\textures\\gui\\loser.png'), (0,0))
    pygame.display.flip()
    time.sleep(5)
    pygame.quit()
main()
