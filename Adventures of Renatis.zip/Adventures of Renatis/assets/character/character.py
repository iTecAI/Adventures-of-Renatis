import requests
from json import loads
from collections import OrderedDict
from random import choice
import webbrowser
import mouse, keyboard
from time import sleep

def get_char(request={},cfgp='character.json'):
    ir = request
    c = 0
    with open(cfgp,'r') as cfgf:
        cfg = loads(cfgf.read(), object_pairs_hook=OrderedDict)
    while not keyboard.is_pressed('x') and c < 100:
        #print(ir)
        request = {}
        #print(ir)
        #print(request)
        for k in cfg.keys():
            if not k in request.keys():
                if type(cfg[k]) == list:
                    subrequest = []
                    for p in cfg[k]:
                        subrequest.append(choice(p))
                    request[k] = '_'.join(subrequest)
                else:
                    for kk in cfg[k].keys():
                        if request[kk.split('=')[0]] == kk.split('=')[1]:
                            subrequest = []
                            for p in cfg[k][kk]:
                                subrequest.append(choice(p))
                            request[k] = '_'.join(subrequest)
        #print(request)
        r = requests.get('http://gaurav.munjal.us/Universal-LPC-Spritesheet-Character-Generator/#',params=request)
        r.url = r.url.split('?')[0] + '#?' + r.url.split('?')[1]
        print(r.url)
        webbrowser.open_new_tab(r.url)
        sleep(2)
        mouse.move(800,500)
        mouse.right_click()
        mouse.move(20,20,absolute=False)
        sleep(0.2)
        mouse.click()
        sleep(1)
        keyboard.send('enter')
        sleep(2)
        c += 1
get_char()
    
